package com.jialu.HibernateMap;

import java.util.HashMap;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmpMain {
	
	public static void main(String[] args) {
		Configuration cfg =  new Configuration();
		cfg.configure("hibernate-cfg.xml");
		
		SessionFactory sf = cfg.buildSessionFactory();
		
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		
		Emp emp = new Emp();
		emp.setId("101");
		emp.setName("Grace");
		
		Map<String, PhoneNumber> map = new HashMap<String, PhoneNumber>();
		PhoneNumber p1 = new PhoneNumber();
		p1.setPid("10");
		p1.setNetwork("FIRE");
		p1.setPhonenumber("237346784327");
		
		PhoneNumber p2 = new PhoneNumber();
		p2.setPid("11");
		p2.setNetwork("BEACON");
		p2.setPhonenumber("353846578423");
		
		map.put(emp.getId(), p1);
		map.put(emp.getId(), p2);
		
		emp.setPhonenumber(map);
		session.persist(emp);
		transaction.commit();
		session.close();
		sf.close();
	}

}
