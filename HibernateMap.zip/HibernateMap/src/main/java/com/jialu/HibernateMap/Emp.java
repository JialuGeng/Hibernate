package com.jialu.HibernateMap;

import java.util.Map;

public class Emp {
	
	private String id;
	private String name;
	private Map<String, PhoneNumber> phonenumber;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Map<String, PhoneNumber> getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(Map<String, PhoneNumber> phonenumber) {
		this.phonenumber = phonenumber;
	}
	
	

}
